# python_autotests
Пример автотестов на pytest + requests
